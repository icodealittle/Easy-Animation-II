package cs5004.animation.model;

/**
 * An enum constructor method that implement different types of shapes for the animation.
 */
public enum ShapeTypes {
  RECTANGLE, OVAL, ELLIPSE;
}
