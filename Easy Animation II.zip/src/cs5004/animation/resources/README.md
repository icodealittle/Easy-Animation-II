This is the README for our Animation Model made by Lisa Lam and Soumeng Chea. We will discuss our
decision choices on the designs for this assignment. Also, we will discuss what we took out, added,
and etc. for this assignment.

As we discussed in the previous assignment – Assignment 7, we both decided to focus our
animation model into two types of interfaces – the ShapesInterface and AnimationInterface, which
would allow us to our animation efficiently. By taking this route, we able to create a
ShapeInterface for our implement shape, which the class method only contains the getter functions.
Since we need to pass any shape implements after its mutation, we do not want the user to be able
to input anything else, which would potentially mess the shape field. By using this approach, we
able to mutate the field shapes within our model command. Otherwise, we would have to iterate and
improvise new objects for every iteration of the animation. If we decided to use a different
approach, it would take thousand of secs to run the program because there are thousands of shapes.
Along with ShapeInterface, we also use an enum class for ShapeTypes, a Position class, and
AbstractShape to implement the necessary getters and constructors for each field without repetitive
codes for each shape. Having two main interface makes it easier to create any shapes and the
implementation of our shape interface.

Another interface constructor that we created is AnimationInterface. Similar to ShapeInterface,
the interface mainly getter command such as getStartState(), getEndState(), and so on.
By implementing a time and shape type, the get state method would return the changes according to
the command line. Along with the interface, we also made an abstract command class –
AbstractAnimation. With this abstract command class, we created a class method where it throws in
an illegal exception statement if either the width or height is negative or if the appearance time
is less than disappearance time. For when we want to change object color, its dimension, and its
move – we decided to create a separate class method, which extends from AbstractAnimation.
We decided to design the three command classes separately because we anticipate that the user would
want to move the shapes around, change the shape color, or enhance the shape size.

# Previous Assignment Summary Ended

# Assignment 8 Start

For this assignment – Assignment 8, we spent days trying to connect our assignment 7 code to the 
AnimationBuilder and AnimationReader. After working on it for quite some time, 
we both came to a conclusion that we decided to scrap everything and went back to square 1. 

For a starter, child – this is probably one of the most confusing and tough assignment out of all
the assignments for this semester. "There is always a light waiting at the end of the tunnel",
Am I right?

Okay, on to what we suppose to be here for. We both decided to start the assignment from scratch
and tried to refactor some of our code to get to "work" with the new stuff and re-design out model.

The first step that we took in this assignment to created new interfaces for the model and also
provided supporting interfaces for the interface. We overhauled our entire builder class to support
the new incoming interface used to create models that was given to us with the new code.
In doing so, we had to redo how we wrote commands as we initially divided commands up based on
what fields were changing. Another change we made was that we added getters for the width, height,
commands, and shapes to our model, making sure that we do not reference the maps that the model
uses to create the animation. And finally, we also implement a new method – draw() and duplicate(),
which we did not have for previous assignment. These methods would help us to draw our shapes for
the animation and make a copy of the shape that we need.

On the new code, we have a total of 5 interfaces for our model functions. Well, technically 4 if we
 exclude AnimationBuilder interface, which was provided by the professor. The interfaces act us a
 ReadOnly methods – Getters and Setters function, for the animation and shapes. We added MCommand. 
 We also created getters for each of the fields of the master command to
 facilitate this update. This MCommand with allows us to update any changes within the fields all
 at once. We also created an Ellipse class that is similar to the oval class since the txt files
 call for an ellipse. 

The main course of this assignment will be focusing on we approach the View commands
of the animation.

In this assignment, we decided to created one interface called IView, which is the main interface
that SVG, Textual, and Visual view all share one common method, play(). This method either starts
the animation in the visual case, or creates the appendable containing the text that represents
the animation in the text cases. We also created an IView extension interface for SVG and Textual
view that only focus on a getText() command  – IViewText. This method only return the string that
represents the animation as a text a description text.

Out of the three classes for Views, the TextualView is probably the most simple out of all.
This class implemented the play() as well as getText() as we formatted. The play() simply just
use as an initialized for the appendable, which goes through shapes and command of the given model.
Their output is a string of the shape start and end time of the shape.

Similarly to TextualView, the SVG is also somewhat simply. Like TextualView, it takes in a model
and gets its commands and shape. The output for which, it creates a string of text in XML format.
This format is a representation of the movement of each shapes. The constructor in SVG would take
in the tick speed and allow the users to implement new input for the animation, whether they want
it to slow down or faster. It initializes each shape with the correct tags and at the correct
location and the writes each of the commands of the shape in their designated tag.

Last View methods, the Visual View methods use a javax swing library that create the animation
and plays it. It takes a model and a ticks per second parameter that sets the speed
of the animation. The animation that is played will set in and use it initialize width and height
in the model, then we uses the scroll bar library that allows the user to scroll to whichever
direction they want the animation to use. The panel of the animation is draw the set in values for
shape. These values are the initialize of how big the shape with be drawn and it starts and ends
time.There is an interface called IDrawAnimationPanel that us used for drawing the shapes 
and is used in the Visual View to create the animation. 

Last but not least, we also wrote a main class called "Main". We wrote this class in a not subtle
nod quality compare to our work. In the method, we look through the given parameter and a method
that allow the user to input their prefer values for the animation.

